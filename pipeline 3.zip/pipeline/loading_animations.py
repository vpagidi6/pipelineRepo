import argparse
import textwrap
import threading
import sys
import time
import keyboard

class Spinner:
    busy = False
    delay = 0.1

    @staticmethod
    def spinning_cursor(animation):
        while 1:
            for cursor in animation: yield cursor

    def __init__(self, delay=None, askingText=""):
        animation = ["⢿", "⢿", "⣻", "⣻", "⣽", "⣽", "⣾", "⣾", "⣷", "⣷", "⣯", "⣯", "⣟", "⣟", "⡿", "⡿"]
        self.spinner_generator = self.spinning_cursor(animation)
        if delay and float(delay):
            self.delay = delay
            self.askingText = askingText

    def spinner_task(self):
        while self.busy:
            sys.stdout.flush()
            sys.stdout.write(self.askingText + " " + next(self.spinner_generator) + "\n")
            sys.stdout.flush()
            time.sleep(self.delay)
            sys.stdout.write("\033[F")
            sys.stdout.write('\b'*len(self.askingText +  " " + next(self.spinner_generator) + "\n"))
            sys.stdout.flush()

    def __enter__(self):
        self.busy = True
        sys.stdout.flush()
        threading.Thread(target=self.spinner_task).start()

    def __exit__(self, exception, value, tb):
        self.busy = False
        time.sleep(self.delay)
        if exception is not None:
            return False

class Processing_Spinner(Spinner):
    busy = False
    delay = 0.3

    def __init__(self, delay=None, askingText=""):
        animation = [
        "[        ]", "[        ]",
        "[=       ]", "[=       ]",
        "[==      ]", "[==      ]",
        "[===     ]", "[===     ]",
        "[====    ]", "[====    ]",
        "[=====   ]", "[=====   ]",
        "[======  ]", "[======  ]",
        "[======= ]", "[======= ]",
        "[========]", "[========]",
        "[ =======]", "[ =======]",
        "[  ======]", "[  ======]",
        "[   =====]", "[   =====]",
        "[    ====]", "[    ====]",
        "[     ===]", "[     ===]",
        "[      ==]", "[      ==]",
        "[       =]", "[       =]",
        "[        ]", "[        ]",
        "[        ]", "[        ]"]
        self.spinner_generator = self.spinning_cursor(animation)
        if delay and float(delay):
            self.delay = delay
            self.askingText = askingText

class Waiting_Spinner(Spinner):
    busy = False
    delay = 0.3

    def __init__(self, delay=None, askingText=""):
        animation = ["◜", "◜", "◝", "◝", "◞", "◞", "◟", "◟"]
        self.spinner_generator = self.spinning_cursor(animation)
        if delay and float(delay):
            self.delay = delay
            self.askingText = askingText

class yn_spinner(Spinner):
    busy = False
    delay = 0.3

    def __init__(self, delay=None, askingText=""):
        self.askingText = askingText
        self.animation = ["◜", "◜", "◝", "◝", "◞", "◞", "◟", "◟"]
        self.spinner_generator = self.spinning_cursor(self.animation)
        if delay and float(delay):
            self.delay = delay

    def __enter__(self):
        self.busy = True
        threading.Thread(target=self.spinner_task).start()
        threading.Thread(target=self.catch_inputs).start()

    def catch_inputs(self):
        while True:
            if keyboard.is_pressed("y"):
                print("y\n")
                break
