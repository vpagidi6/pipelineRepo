import nibabel as nib
import numpy as np
from tkinter import *
from tkscrolledframe import ScrolledFrame
import matplotlib
#matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, CheckButtons
import time
import math
import SimpleITK as sitk
import os
from brukerapi.dataset import Dataset

class eliminateDirections:
	def __init__(self, directions):
		self.status = {}
		self.vars = []

		self.directions = directions
		self.window = Tk()
		self.window.title("Eliminate Directions")

		self.frame_top = Frame(self.window, width=200, height=500)
		self.frame_top.pack(side="top", expand=1, fill="both")

		self.sf = ScrolledFrame(self.frame_top, width=200, height=200)
		self.sf.pack(side="top", expand=1, fill="both")

		self.sf.bind_arrow_keys(self.frame_top)
		self.sf.bind_scroll_wheel(self.frame_top)

		self.frame = self.sf.display_widget(Frame)

		#scroll_bar = Scrollbar(self.window)
		#scroll_bar.pack(side=RIGHT)

	def selection(self):
		for i, s in enumerate(self.vars):
			self.status[f"B{str(i)}"] = s.get()

	def run(self):
		for x in range(0, self.directions):
			var = IntVar()
			self.vars.append(var)
			self.status[f"B{str(x)}"] = 1
			c = Checkbutton(self.frame, text='B'+str(x),variable=var, onvalue=1, offvalue=0, command=self.selection)
			c.select()
			c.pack()

	def get_vals(self):
		return self.status
		#self.window.mainloop()

class qualityChecker:
	def __init__(self, img, nii):
		self.axarr0Click = False
		self.axarr1Click = False
		self.axarr2Click = False

		if not nii:
			self.img = Dataset(img).data
			nib.save(nib.Nifti1Image(self.img, None), os.path.join(os.getcwd(),"cache/", "temp.nii"))
			sitk_t1 = sitk.ReadImage(os.path.join(os.getcwd(),"cache/", "temp.nii"))
			self.img = sitk.GetArrayFromImage(sitk_t1)
		else:
			sitk_t1 = sitk.ReadImage(img)
			self.img = sitk.GetArrayFromImage(sitk_t1)

		#self.img = nib.load(img).get_fdata()
		#img = nib.load("/Users/atulphadke/Documents/Intel_Work/pipeline/test/new_niiOG.nii").get_fdata()
		self.AXIS2 = self.img.shape[-1]
		self.AXIS0 = self.img.shape[-2]
		self.AXIS1 = self.img.shape[-3]

		self.DIRECTION = 0

		self.f, self.axarr = plt.subplots(1, 3, figsize=(10,5))
		self.f.suptitle("B"+str(self.DIRECTION)+" Image", fontsize=15, fontweight="bold")
		self.axarr[1].set_title("Coronal", fontsize=12)
		self.axarr[0].set_title("Axial", fontsize=12)
		self.axarr[2].set_title("Saggital", fontsize=12)


		self.CURRENT1 = round(self.AXIS1/2)
		self.CURRENT0 = round(self.AXIS0/2)
		self.CURRENT2 = round(self.AXIS2/2)
		#print(self.CURRENT2)

		###FIXING
		#axarr[1].text(0.5, -0.4, "hey", fontweight="bold",horizontalalignment='center', verticalalignment='center', transform=axarr[1].transAxes)
		self.axarr[1].set_xlabel(str(self.CURRENT1)+"/"+str(self.AXIS1))
		self.axarr[0].set_xlabel(str(self.CURRENT0)+"/"+str(self.AXIS0))
		self.axarr[2].set_xlabel(str(self.CURRENT2)+"/"+str(self.AXIS2))

		self.img0 = self.axarr[0].imshow(self.img[self.DIRECTION,:,self.CURRENT0,:], cmap='gray')
		self.img1 = self.axarr[1].imshow(self.img[self.DIRECTION,self.CURRENT1,:,:], cmap='gray')
		self.img2 = self.axarr[2].imshow(self.img[self.DIRECTION,:,:,self.CURRENT2], cmap='gray')

		self.axprev = self.f.add_axes([0.7, 0.05, 0.1, 0.075])
		self.axnext = self.f.add_axes([0.81, 0.05, 0.1, 0.075])
		self.axfinish = self.f.add_axes([0.05, 0.05, 0.1, 0.075])
		#self.ax_elim = self.f.add_axes([0.412, 0.85, 0.2, 0.04])
		self.ax_check = self.f.add_axes([0.01, 0.75, 0.15, 0.2])

		self.ax0background = self.f.canvas.copy_from_bbox(self.axarr[0].bbox)
		self.axbackground = self.f.canvas.copy_from_bbox(self.axarr[1].bbox)
		self.ax2background = self.f.canvas.copy_from_bbox(self.axarr[2].bbox)

		self.eliminate = None
		self.check_status = []
		self.b_images = []
		self.vis = []
		for x in range(0, self.img.shape[0]):
			self.b_images.append("b"+str(x))
			self.vis.append(True)

		self.directions = {}

		for b in self.b_images:
			self.directions[str(b)] = True

		self.check = CheckButtons(self.ax_check, ["Keep Direction"], [True])
		self.check.on_clicked(self.func)
		#check = CheckButtons(self.ax_check, self.b_images, self.vis)
		#plt.gcf().set_size_inches(4, 4)

	def onclick_select(self, event):
		if event.inaxes == self.axarr[1]:
			if self.axarr1Click:
				self.axarr1Click = False
			else:
				self.axarr1Click = True
				self.axarr0Click = False
				self.axarr2Click = False
		elif event.inaxes == self.axarr[0]:
			if self.axarr0Click:
				self.axarr0Click = False
			else:
				self.axarr0Click = True
				self.axarr1Click = False
				self.axarr2Click = False
		elif event.inaxes == self.axarr[2]:
			if self.axarr2Click:
				self.axarr2Click = False
			else:
				self.axarr2Click = True
				self.axarr0Click = False
				self.axarr1Click = False
		elif event.inaxes == self.axnext:
			if self.DIRECTION < (self.img.shape[0]-1):
				self.DIRECTION +=1
				self.img0.set_data(self.img[self.DIRECTION, :,self.CURRENT0,:])
				self.img1.set_data(self.img[self.DIRECTION,self.CURRENT1, :, :])
				self.img2.set_data(self.img[self.DIRECTION,:,:,self.CURRENT2])
				self.f.suptitle("B"+str(self.DIRECTION)+" Image", fontsize=15, fontweight="bold")
				print(self.directions["b"+str(self.DIRECTION)])
				if self.directions["b"+str(self.DIRECTION)] and not self.check.lines[0][0].get_visible():
					self.check.set_active(0)

				if not self.directions["b"+str(self.DIRECTION)] and self.check.lines[0][0].get_visible():
					self.check.set_active(0)

				self.f.canvas.draw_idle()
				#print(self.directions)

		elif event.inaxes == self.axprev:
			if self.DIRECTION > 0:
				self.DIRECTION -=1
				self.img0.set_data(self.img[self.DIRECTION, :,self.CURRENT0,:])
				self.img1.set_data(self.img[self.DIRECTION,self.CURRENT1, :, :])
				self.img2.set_data(self.img[self.DIRECTION,:,:,self.CURRENT2])
				self.f.suptitle("B"+str(self.DIRECTION)+" Image", fontsize=15, fontweight="bold")
				self.f.canvas.draw_idle()
				if self.directions["b"+str(self.DIRECTION)] and not self.check.lines[0][0].get_visible():
					self.check.set_active(0)

				if not self.directions["b"+str(self.DIRECTION)] and self.check.lines[0][0].get_visible():
					self.check.set_active(0)

		elif event.inaxes == self.axfinish:
			plt.close()

	def func(self,label):
		print(self.check.lines[0][0].get_visible())
		if self.check.lines[0][0].get_visible():
			self.directions["b"+str(self.DIRECTION)] = True
		else:
			self.directions["b"+str(self.DIRECTION)] = False

	def mouse_move(self, event):
		if event.inaxes == self.axarr[1]:
			if self.axarr1Click:
				x, y = round(event.xdata), round(event.ydata)
				if x > self.img.shape[-2]:
					x = self.img.shape[-2]
				if y > self.img.shape[-1]:
					y = self.img.shape[-1]
				self.img0.set_data(self.img[self.DIRECTION,:,x,:])
				self.img2.set_data(self.img[self.DIRECTION,:,:,y])

				self.axarr[0].set_xlabel(str(x)+"/"+str(self.AXIS0))
				self.axarr[2].set_xlabel(str(y)+"/"+str(self.AXIS2))
				self.CURRENT0 = x
				self.CURRENT2 = y
				self.f.canvas.draw_idle()
				self.f.canvas.flush_events()
				plt.pause(0.000001)
		elif event.inaxes == self.axarr[0]:
			if self.axarr0Click:
				x, y = round(event.xdata), round(event.ydata)
				if x > self.img.shape[-1]:
					x = self.img.shape[-1]
				if y > self.img.shape[1]:
					y = self.img.shape[1]

				self.img1.set_data(self.img[self.DIRECTION,y,:,:])
				self.img2.set_data(self.img[self.DIRECTION,:,:,x])
				self.axarr[1].set_xlabel(str(y)+"/"+str(self.AXIS1))
				self.axarr[2].set_xlabel(str(x)+"/"+str(self.AXIS2))
				self.CURRENT1 = y
				self.CURRENT2 = x
				self.f.canvas.draw_idle()
				self.f.canvas.flush_events()
				plt.pause(0.000001)
		elif event.inaxes == self.axarr[2]:
			if self.axarr2Click:
				x, y = round(event.xdata), round(event.ydata)
				if x > self.img.shape[-2]:
					x = self.img.shape[-2]
				if y > self.img.shape[1]:
					y = self.img.shape[1]
				self.img0.set_data(self.img[self.DIRECTION,:,x,:])
				self.img1.set_data(self.img[self.DIRECTION,y,:,:])
				self.axarr[0].set_xlabel(str(x)+"/"+str(self.AXIS0))
				self.axarr[1].set_xlabel(str(y)+"/"+str(self.AXIS1))
				self.CURRENT0 = x
				self.CURRENT1 = y
				self.f.canvas.draw_idle()
				self.f.canvas.flush_events()
				plt.pause(0.000001)
	def run(self):

		bnext = Button(self.axnext, 'Next')

		bprev = Button(self.axprev, 'Previous')

		finish = Button(self.axfinish, "Finish")

		#elim = Button(self.ax_elim, "Eliminate Directions"

		directions = self.img.shape[0]
		
		self.f.canvas.mpl_connect("button_press_event",self.onclick_select)
		self.f.canvas.mpl_connect("motion_notify_event",self.mouse_move)

		plt.show()

		return self.directions

qual = qualityChecker(img="/Users/atulphadke/Documents/Intel_Work/pipeline/test/new_niiOG.nii", nii=True)
s = qual.run()
print(s)

#x = input()
