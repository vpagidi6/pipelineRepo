from loading_animations import *
import keyboard


with Waiting_Spinner(delay=0.15, askingText="Would you like to split the image by an axis? (y\\n)"):
    while True:
        if keyboard.is_pressed("y"):
            print("here")
            break
