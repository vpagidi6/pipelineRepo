import argparse
import textwrap
import threading
import sys
import time
import subprocess
import os
import keyboard

from tkinter import Tk
from tkinter import filedialog as fd

from brukerapi.dataset import Dataset

from dipy.io.image import load_nifti, save_nifti
from dipy.io import read_bvals_bvecs
from dipy.core.gradients import gradient_table
from dipy.reconst.dti import TensorModel
from dipy.segment.mask import median_otsu
import dipy.reconst.dti as dti
from dipy.core.histeq import histeq

import nibabel as nib
import os
import numpy as np

eng = matlab.engine.start_matlab()

"""class Registration:
    def __init__(self):
        pass
    def manualReg(self):
        pass
    def autoReg(self):
        pass
"""
